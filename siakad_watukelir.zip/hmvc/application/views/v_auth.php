<?php echo form_open('auth/login');?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $title ?></title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/vendor.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/flat-admin.css">

  <!-- Theme -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/theme/blue-sky.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/theme/blue.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/theme/red.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/theme/yellow.css">
  <link href="<?php echo base_url();?>assets/css/sweetalert.css" rel="stylesheet" type="text/css" />
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/sweetalert.min.js"></script>
  <script type="text/javascript">
    var base_url = "<?php echo base_url();?>";
  </script>

</head>
<body>
  <div class="app app-default">

<div class="app-container app-login">
  <div class="flex-center">
    <div class="app-header"></div>
    <div class="app-body">
      <div class="loader-container text-center">
          <div class="icon">
            <div class="sk-folding-cube">
                <div class="sk-cube1 sk-cube"></div>
                <div class="sk-cube2 sk-cube"></div>
                <div class="sk-cube4 sk-cube"></div>
                <div class="sk-cube3 sk-cube"></div>
              </div>
            </div>
          <div class="title">Logging in...</div>
      </div>
      <div class="app-block">
      <div class="app-form">
        <div class="form-header">
          <div class="app-brand"><span class="highlight">Silahkan</span> Login</div>
        </div>
        <form action="/" method="POST">
        <center><b><?php echo $eror; ?></b></center>
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon1">
                <i class="fa fa-user" aria-hidden="true"></i></span>
              <input type="text" class="form-control" name="username" placeholder="Username" aria-describedby="basic-addon1">
            </div>
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon2">
                <i class="fa fa-key" aria-hidden="true"></i></span>
              <input type="password" class="form-control" name="password" placeholder="Password" aria-describedby="basic-addon2">
            </div>
            <div>
              <?php echo $this->recaptcha->render(); ?>
            </div>
            <div class="text-center">
                <input type="submit" class="btn btn-success btn-submit" value="Login">
            </div>
        </form>
      </div>
      </div>
    </div>
    <div class="app-footer">
    </div>
  </div>
</div>

  </div>
  
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/vendor.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/app.js"></script>

</body>
</html>