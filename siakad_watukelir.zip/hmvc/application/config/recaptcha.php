<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// To use reCAPTCHA, you need to sign up for an API key pair for your site.
// link: http://www.google.com/recaptcha/admin
$config['recaptcha_sitekey'] = '6LdkuD4UAAAAAO0HynNyP8oFXf65XrKssnLHrUlS';
$config['recaptcha_secretkey'] = '6LdkuD4UAAAAAFT6YlXqAY5iyEXUU7RwiPRrbpbJ';

// reCAPTCHA supported 40+ languages listed here:
// https://developers.google.com/recaptcha/docs/language
$config['recaptcha_lang'] = 'en';

/* End of file recaptcha.php */
/* Location: ./application/config/recaptcha.php */