<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
  <title>Halaman Admin</title>
  
<?php echo $this->load->view(HEADER,NULL, true); ?>

</head>
<body>
  <div class="app app-default">

<?php echo $this->load->view(SIDEBAR,NULL, true); ?>

<script type="text/ng-template" id="sidebar-dropdown.tpl.html">
  <div class="dropdown-background">
    <div class="bg"></div>
  </div>
  <div class="dropdown-container">
    {{list}}
  </div>
</script>
<div class="app-container">

<?php echo $this->load->view(NAVBAR,NULL, true); ?>

  <div class="btn-floating" id="help-actions">
  <div class="btn-bg"></div>
  <button type="button" class="btn btn-default btn-toggle" data-toggle="toggle" data-target="#help-actions">
    <i class="icon fa fa-plus"></i>
    <span class="help-text">Shortcut</span>
  </button>
  <div class="toggle-content">
    <ul class="actions" align="center">
      <li><a href="#">Halaman Web</a></li>
      <li><a href="#">Documentation</a></li>
      <li><a href="#">Profile</a></li>
      <li><a href="<?php echo base_url(); ?>auth/logout">Logout</a></li>
    </ul>
  </div>
</div>
<div class="row">
  <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
      <a class="card card-banner card-green-light">
  <div class="card-body">
    <i class="icon fa fa-shopping-basket fa-4x"></i>
    <div class="content">
      <div class="title">Sale Today</div>
      <div class="value"><span class="sign">$</span>420</div>
    </div>
  </div>
</a>

  </div>
  <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
      <a class="card card-banner card-blue-light">
  <div class="card-body">
    <i class="icon fa fa-thumbs-o-up fa-4x"></i>
    <div class="content">
      <div class="title">Page Likes</div>
      <div class="value"><span class="sign"></span>2453</div>
    </div>
  </div>
</a>

  </div>
  <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
      <a class="card card-banner card-yellow-light">
  <div class="card-body">
    <i class="icon fa fa-user-plus fa-4x"></i>
    <div class="content">
      <div class="title">New Registration</div>
      <div class="value"><span class="sign"></span>50</div>
    </div>
  </div>
</a>

  </div>
</div>

<?php echo $main_content; ?>
<?php echo $this->load->view(FOOTER,NULL, true); ?>
</body>
</html>