    <footer class="app-footer"> 
      <div class="row">
        <div class="col-xs-12">
          <div class="footer-copyright">
            Copyright © 2016 Company Co,Ltd.
          </div>
        </div>
      </div>
    </footer>
  </div>
</div>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/vendor.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/app.js"></script>