<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_auth extends CI_Model{
    public function __construct(){
        parent::__construct();
    }
    public function authenticate($post){
        $this->db->where(array(
            "username" => $this->db->escape_like_str($post['username']),
            "password" => md5($post['password']),
            "status" => 1,
        ));
        return $this->db->get('users_auth');
    }
}